from project.animal import Animal


class Mammal(Animal):
    pass